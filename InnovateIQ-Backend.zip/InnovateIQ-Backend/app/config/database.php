<?php

namespace App\Config;

use PDO;
use PDOException;

class Database {
    private static $connection = null;
    private static $connectionError = null;

    public static function getConnection() {
        if (self::$connection === null) {
            $host = $_ENV['DB_HOST'] ?? '127.0.0.1';
            $port = $_ENV['DB_PORT'] ?? '3306';
            $db_name = $_ENV['DB_DATABASE'] ?? 'innovate_iq_db';
            $username = $_ENV['DB_USERNAME'] ?? 'root';
            $password = $_ENV['DB_PASSWORD'] ?? '';

            try {
                $dsn = "mysql:host={$host};port={$port};dbname={$db_name};charset=utf8mb4";
                self::$connection = new PDO($dsn, $username, $password);
                self::$connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                self::$connection->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            } catch(PDOException $exception) {
                self::$connection = null;
                self::$connectionError = $exception->getMessage();
            }
        }
        return self::$connection;
    }

    public static function getConnectionError() {
        return self::$connectionError;
    }
}

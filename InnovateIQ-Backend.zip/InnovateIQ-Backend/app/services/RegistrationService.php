<?php

namespace App\Services;

use App\Repositories\RegistrationRepository;

class RegistrationService {
    private $registrationRepo;

    public function __construct() {
        $this->registrationRepo = new RegistrationRepository();
    }

    public function registerParticipant($data) {
        if (empty($data['email_address']) && empty($data['email'])) {
            throw new \Exception("Email is required for registration.");
        }

        return $this->registrationRepo->create($data);
    }

    public function getAllRegistrations() {
        return $this->registrationRepo->getAll();
    }

    public function updateStatus($code, $status) {
        return $this->registrationRepo->updateStatus($code, $status);
    }

    public function updateRegistration($data) {
        return $this->registrationRepo->update($data);
    }
}

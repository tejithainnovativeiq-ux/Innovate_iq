<?php

namespace App\Services;

use App\Repositories\RegistrationRepository;

class DashboardService {
    private $registrationRepo;

    public function __construct() {
        $this->registrationRepo = new RegistrationRepository();
    }

    public function getOverviewStats() {
        return $this->registrationRepo->getOverviewStats();
    }
}

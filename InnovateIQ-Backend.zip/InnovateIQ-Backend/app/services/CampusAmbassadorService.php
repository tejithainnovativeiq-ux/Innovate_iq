<?php
namespace App\Services;

use App\Repositories\CampusAmbassadorRepository;

class CampusAmbassadorService {
    private $ambassadorRepository;

    public function __construct() {
        $this->ambassadorRepository = new CampusAmbassadorRepository();
    }

    public function getAllAmbassadors() {
        return $this->ambassadorRepository->getAll();
    }

    public function updateStatus($code, $status) {
        return $this->ambassadorRepository->updateStatus($code, $status);
    }

    public function updateAmbassador($code, $data) {
        return $this->ambassadorRepository->update($code, $data);
    }

    public function registerAmbassador($data) {
        return $this->ambassadorRepository->create($data);
    }
}

<?php

namespace App\Services;

use App\Repositories\RegistrationRepository;

class ExportService {
    private $registrationRepo;

    public function __construct() {
        $this->registrationRepo = new RegistrationRepository();
    }

    public function generateCsv() {
        $records = $this->registrationRepo->getAll(1000);

        if (empty($records)) {
            return "No data found";
        }

        $output = [];
        // Header
        $output[] = implode(",", array_keys($records[0]));

        // Rows
        foreach ($records as $row) {
            $escapedRow = array_map(function($field) {
                return '"' . str_replace('"', '""', $field ?? '') . '"';
            }, array_values($row));
            $output[] = implode(",", $escapedRow);
        }

        return implode("\n", $output);
    }
}

<?php

namespace App\Services;

class AuthService {
    public function authenticateUser($credentials) {
        // Mock Authentication Logic
        if (empty($credentials['email']) || empty($credentials['password'])) {
            throw new \Exception("Missing credentials");
        }

        if ($credentials['email'] === 'admin@innovateiq.com' && $credentials['password'] === 'secret') {
            return "mock-jwt-token-123456";
        }
        
        throw new \Exception("Invalid credentials");
    }
}

<?php
namespace App\Repositories;

use App\Config\Database;
use PDO;

class CampusAmbassadorRepository {
    private $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    private function checkConnection() {
        if (!$this->db) {
            $err = Database::getConnectionError();
            throw new \Exception("Database connection not available: " . ($err ?: "Unknown error"));
        }
    }

    public function getAll() {
        $this->checkConnection();
        $stmt = $this->db->query("SELECT * FROM campus_ambassador_registrations ORDER BY id DESC");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function updateStatus($code, $status) {
        $this->checkConnection();
        $stmt = $this->db->prepare("UPDATE campus_ambassador_registrations SET application_status = ? WHERE registration_code = ?");
        $stmt->execute([$status, $code]);
        return $stmt->rowCount() > 0;
    }

    public function update($code, $data) {
        $this->checkConnection();
        $stmt = $this->db->prepare("UPDATE campus_ambassador_registrations SET full_name = ?, email_address = ?, mobile_number = ?, gender = ?, college_name = ?, course_name = ?, year_of_study = ?, reason_for_joining = ?, application_status = ? WHERE registration_code = ?");
        $stmt->execute([
            $data['full_name'],
            $data['email_address'],
            $data['mobile_number'],
            $data['gender'],
            $data['college_name'],
            $data['course_name'],
            $data['year_of_study'],
            $data['reason_for_joining'],
            $data['application_status'],
            $code
        ]);
        return $stmt->rowCount() > 0;
    }

    public function create($data) {
        $this->checkConnection();
        
        $year = date('Y');
        $stmt = $this->db->query("SELECT MAX(id) FROM campus_ambassador_registrations");
        $maxId = (int) $stmt->fetchColumn();
        $nextId = $maxId + 1;
        $registrationCode = sprintf("IIQ-CA-%s-%06d", $year, $nextId);

        $sql = "INSERT INTO campus_ambassador_registrations (
            registration_code, full_name, gender, date_of_birth, mobile_number, email_address,
            whatsapp_number, residential_address, college_name, college_type, university_board,
            course_name, branch_specialization, year_of_study, current_semester, expected_passing_year,
            academic_score, roll_registration_number, college_address, interests, technical_skills,
            soft_skills, achievements_certifications, student_club_member, event_organizing_experience,
            weekly_availability, preferred_working_mode, reason_for_joining, promotion_plan,
            linkedin_url, social_handle, faculty_reference, documents, declaration_accepted,
            declaration_accepted_at
        ) VALUES (
            :registration_code, :full_name, :gender, :date_of_birth, :mobile_number, :email_address,
            :whatsapp_number, :residential_address, :college_name, :college_type, :university_board,
            :course_name, :branch_specialization, :year_of_study, :current_semester, :expected_passing_year,
            :academic_score, :roll_registration_number, :college_address, :interests, :technical_skills,
            :soft_skills, :achievements_certifications, :student_club_member, :event_organizing_experience,
            :weekly_availability, :preferred_working_mode, :reason_for_joining, :promotion_plan,
            :linkedin_url, :social_handle, :faculty_reference, :documents, :declaration_accepted,
            :declaration_accepted_at
        )";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            ':registration_code' => $registrationCode,
            ':full_name' => $data['full_name'],
            ':gender' => $data['gender'],
            ':date_of_birth' => $data['date_of_birth'],
            ':mobile_number' => $data['mobile_number'],
            ':email_address' => $data['email_address'],
            ':whatsapp_number' => $data['whatsapp_number'] ?? null,
            ':residential_address' => $data['residential_address'],
            ':college_name' => $data['college_name'],
            ':college_type' => $data['college_type'] ?? 'Engineering College',
            ':university_board' => $data['university_board'] ?? 'Other',
            ':course_name' => $data['course_name'],
            ':branch_specialization' => $data['branch_specialization'] ?? '',
            ':year_of_study' => $data['year_of_study'] ?? '1st Year',
            ':current_semester' => $data['current_semester'] ?? 1,
            ':expected_passing_year' => $data['expected_passing_year'] ?? 2026,
            ':academic_score' => $data['academic_score'] ?? '',
            ':roll_registration_number' => $data['roll_registration_number'] ?? null,
            ':college_address' => $data['college_address'] ?? '',
            ':interests' => $data['interests'] ?? '[]',
            ':technical_skills' => $data['technical_skills'] ?? '[]',
            ':soft_skills' => $data['soft_skills'] ?? '[]',
            ':achievements_certifications' => $data['achievements_certifications'] ?? null,
            ':student_club_member' => $data['student_club_member'] ?? 'No',
            ':event_organizing_experience' => $data['event_organizing_experience'] ?? 'No',
            ':weekly_availability' => $data['weekly_availability'] ?? '2-4 Hours',
            ':preferred_working_mode' => $data['preferred_working_mode'] ?? 'Online',
            ':reason_for_joining' => $data['reason_for_joining'] ?? '',
            ':promotion_plan' => $data['promotion_plan'] ?? '',
            ':linkedin_url' => $data['linkedin_url'] ?? null,
            ':social_handle' => $data['social_handle'] ?? null,
            ':faculty_reference' => $data['faculty_reference'] ?? null,
            ':documents' => $data['documents'] ?? '{"college_id":null,"resume":null,"photo":null,"bonafide":null}',
            ':declaration_accepted' => $data['declaration_accepted'] ?? 1,
            ':declaration_accepted_at' => date('Y-m-d H:i:s')
        ]);

        return $this->findByCode($registrationCode);
    }

    public function findByCode($code) {
        $this->checkConnection();
        $stmt = $this->db->prepare("SELECT * FROM campus_ambassador_registrations WHERE registration_code = ?");
        $stmt->execute([$code]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}

<?php
namespace App\Repositories;

use App\Config\Database;
use PDO;

class RegistrationRepository {
    private $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }
    private function checkConnection() {
        if (!$this->db) {
            $err = Database::getConnectionError();
            throw new \Exception("Database connection not available: " . ($err ?: "Unknown error"));
        }
    }

    /**
     * Get aggregate statistics from registrations_data
     */
    public function getOverviewStats() {
        $this->checkConnection();

        // Total registrations
        $totalStmt = $this->db->query("SELECT COUNT(*) as total FROM registrations_data");
        $total = (int) $totalStmt->fetchColumn();

        // Count by academic status
        $graduatedStmt = $this->db->query("SELECT COUNT(*) FROM registrations_data WHERE academic_status = 'Graduated'");
        $graduated = (int) $graduatedStmt->fetchColumn();

        $pursuingStmt = $this->db->query("SELECT COUNT(*) FROM registrations_data WHERE academic_status LIKE '%Pursuing%' OR academic_status LIKE '%Student%'");
        $pursuing = (int) $pursuingStmt->fetchColumn();

        // Domain breakdown
        $domainStmt = $this->db->query("SELECT primary_domain, COUNT(*) as count FROM registrations_data GROUP BY primary_domain");
        $domainBreakdown = $domainStmt->fetchAll(PDO::FETCH_KEY_PAIR);

        return [
            "total_registrations" => $total,
            "graduated_count" => $graduated,
            "pursuing_count" => $pursuing,
            "pending_approvals" => $total - $graduated,
            "domain_breakdown" => $domainBreakdown
        ];
    }

    /**
     * Get all registrations with optional limit/filters
     */
    public function getAll($limit = 100) {
        $this->checkConnection();

        $stmt = $this->db->prepare("SELECT * FROM registrations_data ORDER BY id DESC LIMIT :limit");
        $stmt->bindValue(':limit', (int) $limit, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Insert a new registration record
     */
    public function create(array $data) {
        $this->checkConnection();

        // Generate unique registration code if not provided
        if (empty($data['registration_code'])) {
            $lastId = $this->db->query("SELECT MAX(id) FROM registrations_data")->fetchColumn();
            $nextId = ((int) $lastId) + 1;
            $data['registration_code'] = sprintf("REG-%s-%04d", date('Y'), $nextId);
        }

        $sql = "INSERT INTO registrations_data (
            registration_code, full_name, date_of_birth, gender, mobile_number, email_address,
            state_name, district_name, city_town, complete_address, highest_qualification, core_branch,
            passout_year, college_university, graduation_score, active_backlogs, intermediate_percentage,
            ssc_percentage, academic_status, primary_domain, secondary_domain, technical_skills,
            projects_description, experience_level, preferred_training_mode, preferred_job_location,
            joining_availability, resume_path, photo_path, linkedin_url, github_portfolio_url,
            referral_source, communication_language, career_objective, declaration_accepted,
            graduating_month, graduating_year
        ) VALUES (
            :registration_code, :full_name, :date_of_birth, :gender, :mobile_number, :email_address,
            :state_name, :district_name, :city_town, :complete_address, :highest_qualification, :core_branch,
            :passout_year, :college_university, :graduation_score, :active_backlogs, :intermediate_percentage,
            :ssc_percentage, :academic_status, :primary_domain, :secondary_domain, :technical_skills,
            :projects_description, :experience_level, :preferred_training_mode, :preferred_job_location,
            :joining_availability, :resume_path, :photo_path, :linkedin_url, :github_portfolio_url,
            :referral_source, :communication_language, :career_objective, :declaration_accepted,
            :graduating_month, :graduating_year
        )";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            ':registration_code'     => $data['registration_code'],
            ':full_name'             => $data['full_name'] ?? 'N/A',
            ':date_of_birth'         => $data['date_of_birth'] ?? date('Y-m-d'),
            ':gender'                => $data['gender'] ?? 'Not Specified',
            ':mobile_number'         => $data['mobile_number'] ?? $data['mobile'] ?? '0000000000',
            ':email_address'         => $data['email_address'] ?? $data['email'] ?? 'n/a@example.com',
            ':state_name'            => $data['state_name'] ?? 'N/A',
            ':district_name'         => $data['district_name'] ?? 'N/A',
            ':city_town'             => $data['city_town'] ?? null,
            ':complete_address'      => $data['complete_address'] ?? 'N/A',
            ':highest_qualification' => $data['highest_qualification'] ?? 'B.Tech',
            ':core_branch'           => $data['core_branch'] ?? null,
            ':passout_year'          => $data['passout_year'] ?? date('Y'),
            ':college_university'    => $data['college_university'] ?? 'N/A',
            ':graduation_score'      => isset($data['graduation_score']) ? (float)$data['graduation_score'] : null,
            ':active_backlogs'       => $data['active_backlogs'] ?? null,
            ':intermediate_percentage'=> $data['intermediate_percentage'] ?? null,
            ':ssc_percentage'        => $data['ssc_percentage'] ?? null,
            ':academic_status'       => $data['academic_status'] ?? 'Registered',
            ':primary_domain'        => $data['primary_domain'] ?? 'Software Development',
            ':secondary_domain'      => $data['secondary_domain'] ?? null,
            ':technical_skills'      => $data['technical_skills'] ?? null,
            ':projects_description'  => $data['projects_description'] ?? null,
            ':experience_level'      => $data['experience_level'] ?? null,
            ':preferred_training_mode'=> $data['preferred_training_mode'] ?? null,
            ':preferred_job_location'=> $data['preferred_job_location'] ?? null,
            ':joining_availability'  => $data['joining_availability'] ?? null,
            ':resume_path'           => $data['resume_path'] ?? 'uploads/resumes/default.pdf',
            ':photo_path'            => $data['photo_path'] ?? null,
            ':linkedin_url'          => $data['linkedin_url'] ?? null,
            ':github_portfolio_url'  => $data['github_portfolio_url'] ?? null,
            ':referral_source'       => $data['referral_source'] ?? null,
            ':communication_language'=> $data['communication_language'] ?? null,
            ':career_objective'      => $data['career_objective'] ?? null,
            ':declaration_accepted'  => isset($data['declaration_accepted']) ? (int)$data['declaration_accepted'] : 0,
            ':graduating_month'      => $data['graduating_month'] ?? null,
            ':graduating_year'       => isset($data['graduating_year']) ? (int)$data['graduating_year'] : null
        ]);

        $insertedId = $this->db->lastInsertId();
        return $this->findById($insertedId);
    }

    public function findById($id) {
        $this->checkConnection();
        $stmt = $this->db->prepare("SELECT * FROM registrations_data WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function updateStatus($code, $status) {
        $this->checkConnection();
        $stmt = $this->db->prepare("UPDATE registrations_data SET academic_status = ? WHERE registration_code = ?");
        $stmt->execute([$status, $code]);
        return ["registration_code" => $code, "academic_status" => $status];
    }

    public function update(array $data) {
        $this->checkConnection();
        
        if (empty($data['registration_code'])) {
            throw new \Exception("Registration code is required for update.");
        }
        
        $sql = "UPDATE registrations_data SET 
            full_name = :full_name,
            email_address = :email_address,
            primary_domain = :primary_domain,
            academic_status = :academic_status,
            preferred_training_mode = :preferred_training_mode,
            career_objective = :career_objective
            WHERE registration_code = :registration_code";
            
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            ':registration_code' => $data['registration_code'],
            ':full_name' => $data['full_name'] ?? null,
            ':email_address' => $data['email_address'] ?? null,
            ':primary_domain' => $data['primary_domain'] ?? null,
            ':academic_status' => $data['academic_status'] ?? null,
            ':preferred_training_mode' => $data['preferred_training_mode'] ?? null,
            ':career_objective' => $data['career_objective'] ?? null
        ]);
        
        return $this->findByCode($data['registration_code']);
    }
    
    public function findByCode($code) {
        $this->checkConnection();
        $stmt = $this->db->prepare("SELECT * FROM registrations_data WHERE registration_code = ?");
        $stmt->execute([$code]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}

<?php
namespace App\Repositories;

use App\Config\Database;

class StatusLogRepository {
    private $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }
}

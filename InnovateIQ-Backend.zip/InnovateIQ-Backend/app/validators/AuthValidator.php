<?php
namespace App\Validators;

class AuthValidator {
    public static function validate($data) {
        return true;
    }
}

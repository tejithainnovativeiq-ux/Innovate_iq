<?php
namespace App\Validators;

class DashboardFilterValidator {
    public static function validate($data) {
        return true;
    }
}

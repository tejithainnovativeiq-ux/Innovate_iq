<?php
namespace App\Validators;

class StatusValidator {
    public static function validate($data) {
        return true;
    }
}

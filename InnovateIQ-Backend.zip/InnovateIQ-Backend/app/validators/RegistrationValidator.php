<?php
namespace App\Validators;

class RegistrationValidator {
    public static function validate($data) {
        // Validation logic stub
        return true;
    }
}

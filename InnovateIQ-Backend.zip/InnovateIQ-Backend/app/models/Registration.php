<?php
namespace App\Models;

class Registration {
    public $id;
    public $name;
    public $email;
    public $status;
}

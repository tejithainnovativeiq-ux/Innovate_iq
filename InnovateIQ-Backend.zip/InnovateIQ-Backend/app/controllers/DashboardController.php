<?php

namespace App\Controllers;

use App\Helpers\Response;
use App\Services\DashboardService;

class DashboardController {
    private $dashboardService;

    public function __construct() {
        $this->dashboardService = new DashboardService();
    }

    public function getStats() {
        try {
            $stats = $this->dashboardService->getOverviewStats();
            Response::success("Dashboard stats retrieved successfully", $stats);
        } catch (\Exception $e) {
            Response::error($e->getMessage(), 500);
        }
    }
}

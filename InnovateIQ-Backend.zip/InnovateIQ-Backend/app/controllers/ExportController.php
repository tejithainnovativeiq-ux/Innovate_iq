<?php

namespace App\Controllers;

use App\Helpers\Response;
use App\Services\ExportService;

class ExportController {
    private $exportService;

    public function __construct() {
        $this->exportService = new ExportService();
    }

    public function exportToCsv() {
        try {
            // Usually this would set headers and stream a CSV file
            $csvData = $this->exportService->generateCsv();
            Response::success("CSV Export generated", ["csv_preview" => $csvData]);
        } catch (\Exception $e) {
            Response::error($e->getMessage(), 500);
        }
    }
}

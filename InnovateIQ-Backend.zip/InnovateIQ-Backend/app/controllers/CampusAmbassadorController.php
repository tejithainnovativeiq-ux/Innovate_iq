<?php
namespace App\Controllers;

use App\Helpers\Response;
use App\Services\CampusAmbassadorService;

class CampusAmbassadorController {
    private $ambassadorService;

    public function __construct() {
        $this->ambassadorService = new CampusAmbassadorService();
    }

    public function index() {
        try {
            $ambassadors = $this->ambassadorService->getAllAmbassadors();
            Response::success("Ambassadors retrieved successfully", $ambassadors);
        } catch (\Exception $e) {
            Response::error($e->getMessage(), 500);
        }
    }

    public function updateStatus() {
        $data = json_decode(file_get_contents('php://input'), true) ?? $_POST;
        
        if (empty($data['registration_code']) || empty($data['application_status'])) {
            Response::error("Missing registration_code or application_status", 400);
            return;
        }

        try {
            $result = $this->ambassadorService->updateStatus($data['registration_code'], $data['application_status']);
            Response::success("Status updated successfully", $result);
        } catch (\Exception $e) {
            Response::error($e->getMessage(), 400);
        }
    }

    public function update() {
        $data = json_decode(file_get_contents('php://input'), true) ?? $_POST;

        if (empty($data['registration_code'])) {
            Response::error("Missing registration_code", 400);
            return;
        }

        try {
            $result = $this->ambassadorService->updateAmbassador($data['registration_code'], $data);
            Response::success("Ambassador details updated successfully", $result);
        } catch (\Exception $e) {
            Response::error($e->getMessage(), 400);
        }
    }

    public function store() {
        $data = json_decode(file_get_contents('php://input'), true) ?? $_POST;
        
        try {
            $result = $this->ambassadorService->registerAmbassador($data);
            Response::success("Campus Ambassador registered successfully", $result, 201);
        } catch (\Exception $e) {
            Response::error($e->getMessage(), 400);
        }
    }
}

<?php

namespace App\Controllers;

use App\Helpers\Response;
use App\Services\AuthService;

class AuthController {
    private $authService;

    public function __construct() {
        $this->authService = new AuthService();
    }

    public function login() {
        $data = json_decode(file_get_contents('php://input'), true) ?? $_POST;
        
        try {
            $token = $this->authService->authenticateUser($data);
            Response::success("Login successful", ["token" => $token]);
        } catch (\Exception $e) {
            Response::error("Invalid credentials", 401);
        }
    }
}

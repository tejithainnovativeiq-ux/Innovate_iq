<?php

namespace App\Controllers;

use App\Helpers\Response;
use App\Services\RegistrationService;

class RegistrationController {
    private $registrationService;

    public function __construct() {
        $this->registrationService = new RegistrationService();
    }

    public function index() {
        try {
            $registrations = $this->registrationService->getAllRegistrations();
            Response::success("Registrations retrieved successfully", $registrations);
        } catch (\Exception $e) {
            Response::error($e->getMessage(), 500);
        }
    }

    public function store() {
        $data = json_decode(file_get_contents('php://input'), true) ?? $_POST;
        
        try {
            $result = $this->registrationService->registerParticipant($data);
            Response::success("Registration successful", $result, 201);
        } catch (\Exception $e) {
            Response::error($e->getMessage(), 400);
        }
    }

    public function updateStatus() {
        $data = json_decode(file_get_contents('php://input'), true) ?? $_POST;
        
        try {
            if (empty($data['registration_code']) || empty($data['academic_status'])) {
                throw new \Exception("registration_code and academic_status are required");
            }
            $result = $this->registrationService->updateStatus($data['registration_code'], $data['academic_status']);
            Response::success("Status updated successfully", $result);
        } catch (\Exception $e) {
            Response::error($e->getMessage(), 400);
        }
    }

    public function update() {
        $data = json_decode(file_get_contents('php://input'), true) ?? $_POST;
        
        try {
            if (empty($data['registration_code'])) {
                throw new \Exception("registration_code is required");
            }
            $result = $this->registrationService->updateRegistration($data);
            Response::success("Registration updated successfully", $result);
        } catch (\Exception $e) {
            Response::error($e->getMessage(), 400);
        }
    }
}

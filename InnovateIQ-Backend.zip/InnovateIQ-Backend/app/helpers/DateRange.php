<?php
namespace App\Helpers;

class DateRange {
    public static function parse($rangeString) {
        // Parsing logic
        return [];
    }
}

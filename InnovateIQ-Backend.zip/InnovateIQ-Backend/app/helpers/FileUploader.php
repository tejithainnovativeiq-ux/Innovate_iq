<?php
namespace App\Helpers;

class FileUploader {
    public static function upload($file, $destination) {
        // Upload logic
        return true;
    }
}

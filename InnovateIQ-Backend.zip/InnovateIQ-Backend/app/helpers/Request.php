<?php
namespace App\Helpers;

class Request {
    public static function input($key, $default = null) {
        return $_REQUEST[$key] ?? $default;
    }
}

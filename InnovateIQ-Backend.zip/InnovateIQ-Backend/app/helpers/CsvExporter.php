<?php
namespace App\Helpers;

class CsvExporter {
    public static function export($data) {
        // Export logic
        return "";
    }
}

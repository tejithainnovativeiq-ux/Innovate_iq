<?php
namespace App\Middleware;

class AuthMiddleware {
    public function handle() {
        // Implementation logic
    }
}

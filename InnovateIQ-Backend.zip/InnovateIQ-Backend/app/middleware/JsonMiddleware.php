<?php
namespace App\Middleware;

class JsonMiddleware {
    public function handle() {
        // Implementation logic
    }
}

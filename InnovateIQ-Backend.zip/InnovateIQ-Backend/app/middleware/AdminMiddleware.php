<?php
namespace App\Middleware;

class AdminMiddleware {
    public function handle() {
        // Implementation logic
    }
}

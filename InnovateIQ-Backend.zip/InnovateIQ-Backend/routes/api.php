<?php

/**
 * API Routes
 */

use App\Controllers\RegistrationController;
use App\Controllers\DashboardController;
use App\Controllers\ExportController;
use App\Controllers\AuthController;
use App\Controllers\CampusAmbassadorController;

header('Content-Type: application/json');

// Route matching logic
if ($requestMethod === 'POST' && $requestUri === '/api/register') {
    $controller = new RegistrationController();
    $controller->store();
} 
elseif ($requestMethod === 'GET' && $requestUri === '/api/registrations') {
    $controller = new RegistrationController();
    $controller->index();
}
elseif ($requestMethod === 'POST' && $requestUri === '/api/registrations/update-status') {
    $controller = new RegistrationController();
    $controller->updateStatus();
}
elseif ($requestMethod === 'POST' && $requestUri === '/api/registrations/update') {
    $controller = new RegistrationController();
    $controller->update();
}
elseif ($requestMethod === 'GET' && $requestUri === '/api/dashboard/stats') {
    $controller = new DashboardController();
    $controller->getStats();
}
elseif ($requestMethod === 'GET' && $requestUri === '/api/export/csv') {
    $controller = new ExportController();
    $controller->exportToCsv();
}
elseif ($requestMethod === 'POST' && $requestUri === '/api/login') {
    $controller = new AuthController();
    $controller->login();
}
elseif ($requestMethod === 'GET' && $requestUri === '/api/ambassadors') {
    $controller = new CampusAmbassadorController();
    $controller->index();
}
elseif ($requestMethod === 'POST' && $requestUri === '/api/ambassadors/update-status') {
    $controller = new CampusAmbassadorController();
    $controller->updateStatus();
}
elseif ($requestMethod === 'POST' && $requestUri === '/api/ambassadors/update') {
    $controller = new CampusAmbassadorController();
    $controller->update();
}
elseif ($requestMethod === 'POST' && $requestUri === '/api/ambassadors/register') {
    $controller = new CampusAmbassadorController();
    $controller->store();
}
else {
    http_response_code(404);
    echo json_encode(["status" => "error", "message" => "API Route not found: $requestMethod $requestUri"]);
}

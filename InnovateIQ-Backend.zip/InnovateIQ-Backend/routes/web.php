<?php

/**
 * Web Routes
 */

$requestPath = rtrim($requestUri, '/');

if ($requestPath === '' || $requestPath === '/' || $requestPath === '/index') {
    // Basic landing or info page
    echo "<h1>Welcome to InnovateIQ Backend</h1>";
    echo "<p>Use <a href='registration.html'>registration.html</a>, <a href='registrations_dashboard_admin.html'>registrations_dashboard_admin.html</a> or <a href='campus_ambassador_admin.html'>campus_ambassador_admin.html</a> to view pages.</p>";
}
elseif ($requestPath === '/login' || $requestPath === '/login.html') {
    require __DIR__ . '/../public/login.html';
}
elseif ($requestPath === '/campus_ambassador_admin' || $requestPath === '/campus_ambassador_admin.html') {
    require __DIR__ . '/../public/campus_ambassador_admin.html';
}
elseif ($requestPath === '/registrations_dashboard_admin' || $requestPath === '/registrations_dashboard_admin.html') {
    require __DIR__ . '/../public/registrations_dashboard_admin.html';
}
elseif ($requestPath === '/registration' || $requestPath === '/registration.html') {
    require __DIR__ . '/../public/registration.html';
}
else {
    http_response_code(404);
    echo "<h1>404 Not Found</h1>";
    echo "<p>Web Route not found: $requestMethod $requestUri</p>";
}

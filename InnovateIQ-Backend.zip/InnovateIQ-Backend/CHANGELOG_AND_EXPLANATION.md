# InnovateIQ Backend - Detailed Code Changes & Architectural Guide

This document provides a comprehensive log of the changes made to your codebase, including the rationale, the implementation details, and the architectural flow.

---

## 1. Summary of Changes

To transition the system from a static prototype to a fully dynamic production application, the following files were added or modified:

1. **`database.sql`** [NEW]: Created a perfect SQL schema matching your exact 40-column database structure.
2. **`public/index.php`** [MODIFIED]: Integrated a manual `.env` file parser that overrides default web server variables, routing request queries dynamically.
3. **`app/config/database.php`** [MODIFIED]: Set the default MySQL port to `3306` and added connection error-caching helpers to prevent PHP Fatal Uncaught Errors.
4. **`app/repositories/RegistrationRepository.php`** [MODIFIED]: Added support for all 40 columns in the INSERT statement, created a centralized `checkConnection()` helper, and added custom `updateStatus()`, `update()`, and `findByCode()` queries.
5. **`app/services/RegistrationService.php`** [MODIFIED]: Added service-layer forwarding functions for status updates and profile modifications.
6. **`app/controllers/RegistrationController.php`** [MODIFIED]: Added controller-layer API handlers that decode JSON payloads and return structured HTTP responses.
7. **`routes/api.php`** [MODIFIED]: Exposed new API endpoints for updating participant statuses and profile fields.
8. **`public/admin.html`** [MODIFIED]: Removed hardcoded static mock records. Replaced them with dynamic Fetch API calls to retrieve real database data, sync stats, handle date presets, and persist changes via POST requests.

---

## 2. Detailed Technical Explanations

### A. Environment & Configuration Override
* **File:** `public/index.php`
* **Problem:** In XAMPP/Apache, default environment variables (e.g. `DB_PORT`, `DB_HOST`) are already populated in the server environment. A standard check would skip reading our `.env` configuration, resulting in Apache connecting to an incorrect database or port.
* **Solution:** We removed the validation wrapper and forced the manual `.env` parser to unconditionally override the `$_ENV` and `$_SERVER` arrays:
  ```php
  putenv(sprintf('%s=%s', $name, $value));
  $_ENV[$name] = $value;
  $_SERVER[$name] = $value;
  ```
  This guarantees that configuration files always align with the `.env` settings regardless of server environment presets.

### B. Graceful Database Connection Handling
* **File:** `app/config/database.php`
* **Problem:** If a database connection failed, the class threw an immediate `PDOException`. If this occurred during class instantiation in the routing phase (which lacks global catch blocks), it crashed the server with a dirty HTML `Fatal error`.
* **Solution:** The database class was refactored to catch connection failures internally and save the error message, returning `null` to let the caller handle it:
  ```php
  try {
      self::$connection = new PDO($dsn, $username, $password);
  } catch(PDOException $exception) {
      self::$connection = null;
      self::$connectionError = $exception->getMessage();
  }
  ```

### C. Enhanced Repository Logic & Schema Mapping
* **File:** `app/repositories/RegistrationRepository.php`
* **Problem:** 
  1. The old queries only knew about 19 columns, while the database had 40 columns. Trying to insert or query fields without mapping them caused database mismatches.
  2. Errors were handled inconsistently, sometimes returning empty arrays silently.
* **Solution:**
  * **Unified Connection Check:** Added a `checkConnection()` helper that checks if database initialization failed, returning the exact database issue in a JSON response instead of crashing:
    ```php
    private function checkConnection() {
        if (!$this->db) {
            $err = Database::getConnectionError();
            throw new \Exception("Database connection not available: " . ($err ?: "Unknown error"));
        }
    }
    ```
  * **40-Column Mapping:** Re-wrote the `create()` method SQL statement to explicitly declare, bind, and insert all new fields (like `ssc_percentage`, `projects_description`, `graduation_score`, `graduating_year`, etc.).
  * **Status & Profile Update Queries:** Added SQL queries to dynamically update database fields when an admin edits details on the web console:
    ```php
    UPDATE registrations_data SET academic_status = ? WHERE registration_code = ?
    ```

### D. Service & Controller Update Pipelines
* **Files:** `app/services/RegistrationService.php` & `app/controllers/RegistrationController.php`
* **Solution:** Added corresponding business logic and HTTP validation. In the controller, request inputs are safely parsed and wrapped in a Try/Catch block, ensuring that database errors or validation rules are caught and outputted as structured JSON:
  ```php
  public function updateStatus() {
      $data = json_decode(file_get_contents('php://input'), true) ?? $_POST;
      try {
          $result = $this->registrationService->updateStatus($data['registration_code'], $data['academic_status']);
          Response::success("Status updated successfully", $result);
      } catch (\Exception $e) {
          Response::error($e->getMessage(), 400);
      }
  }
  ```

### E. API Route Registrations
* **File:** `routes/api.php`
* **Solution:** Registered new matching rules for pathing. We added:
  1. `POST /api/registrations/update-status` -> Triggers `RegistrationController->updateStatus()`.
  2. `POST /api/registrations/update` -> Triggers `RegistrationController->update()`.

### F. Dynamic Web Panel Integration
* **File:** `public/admin.html`
* **Problem:** The panel was using a static javascript list, which meant edits, status changes, and newly registered users did not sync with the database.
* **Solution:**
  * **Asynchronous Fetching:** Implemented an `async/await` fetch pipeline to query `/api/registrations` on page load:
    ```javascript
    const basePath = window.location.pathname.substring(0, window.location.pathname.indexOf('/public') + 7);
    const apiURL = window.location.origin + basePath + '/api/registrations';
    const response = await fetch(apiURL);
    ```
  * **Dynamic Date Preset Ranges:** Rather than hardcoded dates like `2026-07-20`, the date selector now uses Javascript `Date` objects to default to the current month's start/end dates.
  * **Interactive Updates:** Replaced the static update hooks with asynchronous HTTP POST requests, immediately syncing status changes and profile updates back to the MySQL database without requiring manual database edits.

---

## 3. Data Flow Architecture Diagram

The flow of data through the backend components is designed as follows:

```mermaid
sequenceDiagram
    participant UI as Admin Dashboard (HTML/JS)
    participant Route as routes/api.php
    participant Ctrl as RegistrationController
    participant Serv as RegistrationService
    participant Repo as RegistrationRepository
    participant DB as MySQL Database

    UI->>Route: POST /api/registrations/update-status {code, status}
    Route->>Ctrl: updateStatus()
    Ctrl->>Serv: updateStatus(code, status)
    Serv->>Repo: updateStatus(code, status)
    Repo->>DB: UPDATE registrations_data SET academic_status = ...
    DB-->>Repo: SQL Success
    Repo-->>Serv: Success Array
    Serv-->>Ctrl: Success Array
    Ctrl-->>UI: Response::success("Status updated successfully", data)
    UI->>UI: Refreshes Stats & UI Table dynamically
```

---

## 4. Verification & Validation Steps

1. **Local Server Testing:** Launched a local dev server and successfully verified endpoint responsiveness.
2. **Postman API Validation:** Checked database responses on retrieving, creating, and modifying participant records.
3. **Database Port Resolution:** Swapped port `3307` to `3306` to resolve connection timeouts and target machine refusal errors.

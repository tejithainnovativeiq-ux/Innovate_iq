document.addEventListener('DOMContentLoaded', () => {
    console.log("Registration JS loaded");
});

document.addEventListener('DOMContentLoaded', () => {
    console.log("Admin Dashboard JS loaded");
});

<?php

/**
 * InnovateIQ Backend - Front Controller
 */

// Enable error reporting for testing
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Check if composer autoload exists
if (file_exists(__DIR__ . '/../vendor/autoload.php')) {
    require __DIR__ . '/../vendor/autoload.php';
}

// Load .env variables manually
if (file_exists(__DIR__ . '/../.env')) {
    $lines = file(__DIR__ . '/../.env', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) continue;
        if (strpos($line, '=') !== false) {
            list($name, $value) = explode('=', $line, 2);
            $name = trim($name);
            $value = trim($value);
            $value = trim($value, "\"'"); // strip outer quotes
            putenv(sprintf('%s=%s', $name, $value));
            $_ENV[$name] = $value;
            $_SERVER[$name] = $value;
        }
    }
}

// Simple router to support API testing in Postman
$requestUri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$requestMethod = $_SERVER['REQUEST_METHOD'];

// Remove subdirectories from URI if not hosted on domain root (assuming InnovateIQ-Backend base path)
$basePath = '/InnovateIQ-Backend/public';
if (strpos($requestUri, $basePath) === 0) {
    $requestUri = substr($requestUri, strlen($basePath));
} else if (strpos($requestUri, '/public') === 0) {
    $requestUri = substr($requestUri, 7);
}

// Default route
if ($requestUri === '' || $requestUri === '/') {
    $requestUri = '/index';
}

// Handle CORS early
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");

if ($requestMethod == 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Route mapping
if (strpos($requestUri, '/api/') === 0) {
    require __DIR__ . '/../routes/api.php';
} else {
    require __DIR__ . '/../routes/web.php';
}
